package ir.types;


public interface IrType {

}
