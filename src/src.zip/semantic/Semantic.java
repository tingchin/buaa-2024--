package semantic;

public class Semantic {

}
