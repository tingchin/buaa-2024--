package mips;

public class MipsGenerator {
}
