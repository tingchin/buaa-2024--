package symbol;

public class FunctionParam extends Symbol {

    public FunctionParam(SymbolType type, String name, int layer) {
        super(type, name, layer);
    }
}
