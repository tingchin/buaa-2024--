package symbol;

public class VariableSymbol extends Symbol {

    public VariableSymbol(SymbolType type, String name, int layer) {
        super(type, name, layer);
    }
}
