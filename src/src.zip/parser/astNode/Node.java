package parser.astNode;


public interface Node {
    public void print();
}
